export default interface SalesRegionData {
  regions: Array<string>,
  data: Array<number>
}
