export default interface ProfitMargin {
  grossProfit: Array<number>,
  netProfit: Array<number>
}