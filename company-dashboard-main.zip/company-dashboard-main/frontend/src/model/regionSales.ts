export default interface RegionSales {
  labels: Array<string>;
  data: Array<number>;
}
