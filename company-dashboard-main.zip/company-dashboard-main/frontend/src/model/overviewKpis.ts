export default interface OverviewKpis {
  sgt: number;
  snt: number;
  gpm: number;
  netIncome: number;
  ebitda: number;
  npm: number;
}
