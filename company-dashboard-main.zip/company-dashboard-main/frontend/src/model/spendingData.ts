export interface SpendingData {
  companyName: string;
  accountID: number;
  spending: number;
}
