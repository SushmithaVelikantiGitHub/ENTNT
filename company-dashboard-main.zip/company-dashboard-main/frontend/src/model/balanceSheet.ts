export default interface BalanceSheet {
  nca: number,
  ca: number,
  cl: number,
  ncl: number,
  e: number,
}